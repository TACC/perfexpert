#define mpn_toomN_sqr mpn_toom2_sqr
#define mpn_toomN_sqr_itch mpn_toom2_sqr_itch
#define MIN_AN MPN_TOOM2_SQR_MINSIZE
#define MAX_AN SQR_TOOM3_THRESHOLD

#include "toom-sqr-shared.h"

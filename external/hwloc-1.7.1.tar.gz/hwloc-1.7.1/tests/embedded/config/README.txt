This file exists solely so that the config/ directory exists in hg and
git checkouts.

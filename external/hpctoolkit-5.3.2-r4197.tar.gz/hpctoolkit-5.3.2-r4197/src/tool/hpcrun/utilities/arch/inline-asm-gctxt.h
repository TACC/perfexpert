#ifndef INLINE_ASM_GCTXT_H
#define INLINE_ASM_GCTXT_H

#include "specific-inline-asm-gctxt.h" // DO NOT chg to <> include syntax:
                                       // uses -I cpp arg to select architecture

#endif // INLINE_ASM_GCTXT_H

#ifndef UCONTEXT_MANIP
#define UCONTEXT_MANIP

#include "specific-ucontext-manip.h" // DO NOT chg to <> include syntax:
                                     // uses -I cpp arg to select architecture

#endif // UCONTEXT_MANIP

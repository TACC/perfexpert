// -*-Mode: C++;-*- // technically C99

// * BeginRiceCopyright *****************************************************
//
// $HeadURL: http://hpctoolkit.googlecode.com/svn/trunk/src/lib/prof-lean/spinlock.h $
// $Id: spinlock.h 4059 2013-01-02 20:08:23Z krentel $
//
// --------------------------------------------------------------------------
// Part of HPCToolkit (hpctoolkit.org)
//
// Information about sources of support for research and development of
// HPCToolkit is at 'hpctoolkit.org' and in 'README.Acknowledgments'.
// --------------------------------------------------------------------------
//
// Copyright ((c)) 2002-2013, Rice University
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
// * Redistributions of source code must retain the above copyright
//   notice, this list of conditions and the following disclaimer.
//
// * Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the
//   documentation and/or other materials provided with the distribution.
//
// * Neither the name of Rice University (RICE) nor the names of its
//   contributors may be used to endorse or promote products derived from
//   this software without specific prior written permission.
//
// This software is provided by RICE and contributors "as is" and any
// express or implied warranties, including, but not limited to, the
// implied warranties of merchantability and fitness for a particular
// purpose are disclaimed. In no event shall RICE or contributors be
// liable for any direct, indirect, incidental, special, exemplary, or
// consequential damages (including, but not limited to, procurement of
// substitute goods or services; loss of use, data, or profits; or
// business interruption) however caused and on any theory of liability,
// whether in contract, strict liability, or tort (including negligence
// or otherwise) arising in any way out of the use of this software, even
// if advised of the possibility of such damage.
//
// ******************************************************* EndRiceCopyright *

//***************************************************************************
//
// File: 
//   $HeadURL: http://hpctoolkit.googlecode.com/svn/trunk/src/lib/prof-lean/spinlock.h $
//
// Purpose:
//   Spin lock
//
// Description:
//   [The set of functions, macros, etc. defined in the file]
//
// Author:
//   [...]
//
//***************************************************************************

#ifndef prof_lean_spinlock_h
#define prof_lean_spinlock_h

#include <stdbool.h>

#include "atomic-op.h"

/*
 * Simple spin lock.
 */

typedef struct spinlock_s {
	volatile long thelock;
} spinlock_t;

#define SPINLOCK_UNLOCKED_VALUE (0L)
#define SPINLOCK_LOCKED_VALUE (1L)
#define INITIALIZE_SPINLOCK(x) { .thelock = (x) }

#define SPINLOCK_UNLOCKED INITIALIZE_SPINLOCK(SPINLOCK_UNLOCKED_VALUE)
#define SPINLOCK_LOCKED INITIALIZE_SPINLOCK(SPINLOCK_LOCKED_VALUE)


/*
 * Note: powerpc needs two memory barriers: isync at the end of _lock
 * and lwsync at the beginning of _unlock.  See JohnMC's Comp 422
 * slides on "IBM Power Weak Memory Model."
 *
 * Technically, the isync could be moved to the assembly code for
 * fetch_and_store().
 */
static inline void 
spinlock_lock(spinlock_t *l)
{
  /* test-and-test-and-set lock */
  for(;;) {
    while (l->thelock != SPINLOCK_UNLOCKED_VALUE); 

    if (fetch_and_store(&l->thelock, SPINLOCK_LOCKED_VALUE) == SPINLOCK_UNLOCKED_VALUE) {
      break;
    }
  }

#if defined(__powerpc__)
  __asm__ __volatile__ ("isync\n");
#endif
}


static inline void 
spinlock_unlock(spinlock_t *l)
{
#if defined(__powerpc__)
  __asm__ __volatile__ ("lwsync\n");
#endif

  l->thelock = SPINLOCK_UNLOCKED_VALUE;
}


static inline bool 
spinlock_is_locked(spinlock_t *l)
{
  return (l->thelock != SPINLOCK_UNLOCKED_VALUE);
}


#endif // prof_lean_spinlock_h

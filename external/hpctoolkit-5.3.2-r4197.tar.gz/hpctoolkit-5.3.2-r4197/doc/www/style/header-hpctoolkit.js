// 1. HPCToolkit Image (height = 71 pixels)
document.write('\
  <img style="position: absolute; top: 0px; left: 0px" \
       src="style/header.gif" /> \
');

// 2. Menu and horizontal rule
document.write('\
  <div style="position: relative; margin-top: 60px; width: 100%; text-align: right;"> \
  <p style="margin: 0px; font-size: small;"> \
    [ <a href="index.html">Home</a> \
    | <a href="overview.html">Overview</a> \
    | <a href="publications.html">Publications</a> ] \
    &bull; \
    [ <a href="software.html">Software/Downloads</a> \
    | <a href="documentation.html">Documentation/Questions</a> ] \
    &bull; \
    [ <a href="info-people.html">People</a> | \
      <a href="info-acks.html">Acks</a> ] \
  </p> \
  </div> \
  <div style="width: 100%;"> \
    <hr /> \
  </div> \
');

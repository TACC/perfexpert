// Footer
document.write('\
  <div style="width: 100%; font-size: small;"> \
    <hr /> \
    <p style="margin: 0px; font-size: small;"> \
      &copy;2000-2011 <a href="http://www.rice.edu">Rice University</a> \
      &bull; \
      <a href="http://www.cs.rice.edu">Rice Computer Science</a> \
    </p> \
    <a href="http://validator.w3.org/check/referer"> \
      <img src="http://www.w3.org/Icons/valid-xhtml10-blue" alt="" height="15" /></a> \
    <a href="http://jigsaw.w3.org/css-validator/check/referer"> \
      <img src="http://www.w3.org/Icons/valid-css-blue" alt="" height="15" /></a> \
  </div> \
');
